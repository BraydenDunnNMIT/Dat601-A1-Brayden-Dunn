use Dat601_ddl
go

--Gets data from `Dat601 a1 ddl` database script and runs queries against it as per Dat601 A1 instructions.

-- Queries for Dat601 assessment one start here. 

--Query one

select ProductName
from Product
Order by ProductName ASC;

--Second query

select ProductID, ProductPrice, ProductName
from product
order by ProductPrice asc, ProductName;

--Third query
select ProductID, ProductPrice, ProductName
from product
order by ProductPrice desc

--Fourth query
select productID, ProductPrice, ProductName
from product 
where ProductPrice = '3.49' 

--Fifth query
select productID, ProductPrice, ProductName
from product 
where ProductPrice < '10' 

--Sixth query
select productID, ProductPrice, ProductName
from product 
where VendorID<> 'DLL01'

--Seventh query
select productID, ProductPrice, ProductName
from product 
where ProductPrice between '5' and '10' 

--Eight query
select productID, ProductPrice, ProductName
from product 
where VendorID<> 'DLL01, BRS01'and ProductPrice > '10' 

--Ninth query
select AVG(ProductPrice)
from product

--Tenth query
select count(CustID) as 'Result' 
from customer 

--Eleventh query 
select count(CustEmail) 
from customer

--Twelevth query
--(Not sure if you wanted them to be on the same table or seperate)
select count(ProductName) as 'product types' or  select min(ProductPrice) as 'Minumum price' 
from product 
select min(ProductPrice) as 'Minumum price' 
from product 
select max(ProductPrice) as 'Maximum price' 
from product 
select avg(ProductPrice) as 'Average price'
from product 

--Thirteenth query
select Vendor.VendorName, Product.ProductName, Product.ProductPrice
from Vendor, Product

--Fourtenth query

SELECT ProductName, itemPrice , Quantity, VendorName
FROM OrderItem oi
INNER JOIN Product pr ON oi.ProductID = pr.ProductID
INNER JOIN Vendor ve ON pr.VendorID = ve.VendorID
WHERE oi.OrderID = 20007;

--Query fifthteen

SELECT CustName, CustContact
FROM Customer cu
INNER JOIN OrderEntry oe ON cu.CustID = oe.CustID
INNER JOIN OrderItem oi ON oe.OrderID = oi.OrderID
WHERE oi.ProductID = 'RGAN01';

--Query sixteen

SELECT CustName, CustCity, COUNT(oe.OrderID) AS TotalOrders
FROM Customer cu
LEFT JOIN OrderEntry oe ON cu.CustID = oe.CustID
GROUP BY cu.CustID, cu.CustName, cu.CustCity

--Query seventeen
SELECT CustName, CustContact, CustEmail
FROM Customer
WHERE CustCity IN ('Nelson', 'Wellington') 

--Query eighteen

CREATE VIEW ViewProductCustomer AS
SELECT DISTINCT cu.*
FROM Customer cu
INNER JOIN OrderEntry oe ON cu.CustID = oe.CustID
INNER JOIN OrderItem oi ON oe.OrderID = oi.OrderID













