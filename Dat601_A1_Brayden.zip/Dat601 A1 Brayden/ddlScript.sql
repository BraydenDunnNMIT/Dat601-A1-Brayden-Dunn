
use master;
go
drop database if exists Dat601_ddl;
go
create database Dat601_ddl;
go
use Dat601_ddl;
go

CREATE TABLE Customer
(
	CustID		CHAR(10)	NOT NULL primary key, 
	CustName	CHAR(50)	NOT NULL,
	CustAddress	CHAR(50)	,
	CustCity	CHAR(50)	,
	CustContact	CHAR(50)	,
	CustPhone	CHAR(15)	,
	CustEmail	CHAR(255)	
);


CREATE TABLE OrderEntry
(
	OrderID		INTEGER		NOT NULL primary key,
	OrderDate	DATETIME	NOT NULL,
	CustID		CHAR(10)	NOT NULL,
	foreign key(CustID) references Customer(CustID),
);


CREATE TABLE Vendor
(
	VendorID		CHAR(10)	NOT NULL primary key,
	VendorName		CHAR(50)	NOT NULL,
	VendorAddress	CHAR(50)	,
	VendorCity		CHAR(50)	,
	VendorPhone		CHAR(15)
);

CREATE TABLE Product
(
	ProductID		CHAR(10)	NOT NULL primary key,
	VendorID		CHAR(10)	NOT NULL,
	ProductName		CHAR(255)	NOT NULL,
	ProductPrice	DECIMAL(8,2)NOT NULL,
	ProductDesc		VARCHAR(100),
	foreign key(VendorID) references Vendor(VendorID),
);

CREATE TABLE OrderItem
(
	OrderID		INTEGER		NOT NULL,
	OrderItem	INTEGER		NOT NULL,
	ProductID	CHAR(10)	NOT NULL,
	Quantity	INTEGER		NOT NULL,
	ItemPrice	DECIMAL(8,2)NOT NULL,
	primary key(OrderID, OrderItem),
	foreign key(ProductID) references product(ProductID),
	foreign key(OrderID) references OrderEntry(OrderID),
);







